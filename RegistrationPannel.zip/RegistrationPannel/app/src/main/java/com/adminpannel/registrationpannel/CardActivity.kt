package com.adminpannel.registrationpannel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import com.adminpannel.registrationpannel.databinding.ActivityMainBinding
import com.adminpannel.registrationpannel.databinding.LayoutcardactivityBinding

class CardActivity : AppCompatActivity() {

    lateinit var binding: LayoutcardactivityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=LayoutcardactivityBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.name.text=intent.getStringExtra("nm")
        binding.email.text=intent.getStringExtra("em")
        binding.mobile.text=intent.getStringExtra("nu")




    }
}